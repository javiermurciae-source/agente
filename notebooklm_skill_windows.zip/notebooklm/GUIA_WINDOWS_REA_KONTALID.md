# 🧠 Skill de NotebookLM para Agentes en Windows (REA & Automatización)

Esta skill permite a tu agente de IA (Claude Code, Antigravity, Cursor, etc.) consultar tus cuadernos de **Google NotebookLM** directamente desde la consola/código, obteniendo respuestas de **Gemini 1.5/2.0 Pro** fundamentadas al 100% en tus propios documentos, con citas exactas de fuentes y **cero alucinaciones**.

---

## ⚡ ¿Por qué es fundamental para REA (Reverse Engineering Anything)?

Cuando haces ingeniería inversa, auditoría o clonación de un software, te enfrentas a un problema crítico: **la saturación de la ventana de contexto del agente**.

Un proyecto REA genera cientos de megabytes de insumos:
1. Tráfico de red interceptado (APIs, JSON payloads, headers de autenticación).
2. Documentación descompilada (bundles de Webpack/Vite, código decompilado de Electron o .NET).
3. Manuales de usuario, especificaciones técnicas y esquemas de base de datos.
4. Transcripciones completas de videos de demostración o tutoriales paso a paso.

Si intentas meter todo eso en los prompts del agente, agotas los tokens en minutos o el modelo pierde coherencia.

### El flujo REA con NotebookLM:
En lugar de cargar los archivos en el agente:
1. Creas un cuaderno en NotebookLM y subes todos los insumos descompilados, schemas y manuales.
2. Tu agente de REA usa esta skill como un **oráculo de consulta ilimitada**.
3. Ante cualquier duda de arquitectura, el agente consulta a NotebookLM:
   - *"¿Qué parámetros exige el endpoint `/api/v1/auth` según los requests capturados?"*
   - *"¿Cuál es la fórmula de cálculo del impuesto según la documentación cargada?"*
4. NotebookLM le responde con la cita exacta del documento o video fuente, y el agente programa el clon con total fidelidad.

---

## 🎯 Ejemplo Real: El Caso Kontalid

En el proyecto de clonación e ingeniería inversa del ERP contable **Kontalid**:
- **Problema**: Había 41 videos tutoriales que explicaban todos los módulos contables, facturación electrónica y reglas de impuestos de la DIAN.
- **Implementación**:
  1. Se transcribieron los 41 videos a texto plano (`01_Creacion_Terceros.txt`, `02_Facturacion_Electronica.txt`, etc.).
  2. Se subieron en lote al cuaderno de Kontalid mediante el script `upload_sources.py`.
  3. Cada vez que el agente necesitaba implementar una vista o una validación tributaria, ejecutaba:
     ```cmd
     python scripts/run.py ask_question.py --question "¿Cómo calcula Kontalid la retención en la fuente y qué campos requiere la tabla de terceros?" --notebook-url "https://notebooklm.google.com/notebook/<ID>"
     ```
  4. NotebookLM le devolvió exactamente los nombres de los campos de la interfaz y la regla de negocio sin que el agente tuviera que leer los 41 archivos a ciegas.

---

## 🛠️ Requisitos e Instalación en Windows

### 1. Prerrequisitos del Sistema
- **Python 3.10 o superior** instalado con la casilla *"Add Python to PATH"* activada.
- **Google Chrome** instalado en Windows (Patchright usa el ejecutable oficial de Chrome para evitar que Google detecte el navegador automatizado).

### 2. Estructura de Carpetas
Descomprime la carpeta `notebooklm` dentro de la carpeta de skills de tu agente:
```text
tu-proyecto/
└── .agents/ (o skills/)
    └── skills/
        └── notebooklm/
            ├── SKILL.md
            ├── GUIA_WINDOWS_REA_KONTALID.md
            ├── requirements.txt
            └── scripts/
                ├── run.py
                ├── auth_manager.py
                ├── ask_question.py
                ├── notebook_manager.py
                ├── upload_sources.py
                └── ...
```

### 3. Instalación de Dependencias
Abre **PowerShell** o **CMD** en la carpeta `notebooklm`:
```cmd
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m patchright install chrome
```

### 4. Autenticación Inicial (Una sola vez)
Para conectar tu cuenta de Google NotebookLM:
```cmd
python scripts/run.py auth_manager.py setup
```
- Se abrirá una ventana visible de Google Chrome.
- Inicia sesión con tu cuenta de Google.
- Una vez dentro de NotebookLM, el script detecta la sesión y guarda las credenciales cifradas localmente en `data/browser_state/`. Las siguientes consultas correrán 100% en segundo plano (headless).

---

## 🚀 Comandos Principales para el Agente

> **Regla de oro**: Siempre invocar los scripts a través de `python scripts/run.py <script>` para asegurar el entorno virtual de Windows.

### Consultar directamente por URL de cuaderno:
```cmd
python scripts/run.py ask_question.py --question "Explica la estructura del módulo de clientes" --notebook-url "https://notebooklm.google.com/notebook/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
```

### Administrar tu biblioteca de cuadernos:
```cmd
# Listar cuadernos guardados
python scripts/run.py notebook_manager.py list

# Registrar un cuaderno en tu biblioteca local
python scripts/run.py notebook_manager.py add --url "https://notebooklm.google.com/notebook/..." --name "Kontalid REA" --description "Transcripciones y esquemas de Kontalid" --topics "erp,contabilidad,rea"

# Preguntar por ID de cuaderno
python scripts/run.py ask_question.py --question "..." --notebook-id <ID>
```

### Subir archivos masivos a un cuaderno:
```cmd
python scripts/run.py upload_sources.py --src "C:\ruta\a\mis_transcripciones" --pattern "*.txt" --notebook "https://notebooklm.google.com/notebook/..."
```
