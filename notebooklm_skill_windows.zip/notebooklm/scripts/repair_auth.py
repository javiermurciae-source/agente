#!/usr/bin/env python3
"""Repair: regenerate state.json from the persistent profile (where the
user already logged in) now that we point at the correct domain."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from patchright.sync_api import sync_playwright
from browser_utils import BrowserFactory
from auth_manager import AuthManager

auth = AuthManager()
pw = None
ctx = None
try:
    pw = sync_playwright().start()
    ctx = BrowserFactory.launch_persistent_context(pw, headless=True)
    page = ctx.new_page()
    page.goto("https://notebook.google.com", wait_until="domcontentloaded", timeout=30000)
    page.wait_for_timeout(3000)
    url = page.url
    print(f"URL final: {url}")
    if "accounts.google.com" in url:
        print("RESULT: NO_AUTENTICADO (redirigió a login)")
        sys.exit(2)
    # Authenticated — persist storage state + metadata
    auth._save_browser_state(ctx)
    auth._save_auth_info()
    print("RESULT: AUTENTICADO_OK")
    sys.exit(0)
except Exception as e:
    print(f"ERROR: {e}")
    sys.exit(1)
finally:
    if ctx:
        try: ctx.close()
        except Exception: pass
    if pw:
        try: pw.stop()
        except Exception: pass
