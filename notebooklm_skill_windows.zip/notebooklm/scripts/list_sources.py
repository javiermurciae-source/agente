#!/usr/bin/env python3
"""Enumerate all source titles currently in a notebook (for audit/cleanup)."""
import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from patchright.sync_api import sync_playwright
from browser_utils import BrowserFactory

import argparse
_ap = argparse.ArgumentParser()
_ap.add_argument("--notebook", default="https://notebook.google.com/notebook/9ffa2db9-ccad-4724-8e32-7b8e2f5c5afd")
_args = _ap.parse_args()

pw = ctx = None
try:
    pw = sync_playwright().start()
    ctx = BrowserFactory.launch_persistent_context(pw, headless=True)
    page = ctx.new_page()
    page.goto(_args.notebook, wait_until="domcontentloaded")
    page.wait_for_timeout(6000)
    try:
        page.click("text=Sources", timeout=6000); page.wait_for_timeout(2500)
    except Exception:
        pass
    # Scroll the source list to load all entries
    for _ in range(60):
        page.mouse.wheel(0, 3000)
        page.wait_for_timeout(150)
    page.wait_for_timeout(1500)
    txt = page.inner_text("body")
    Path("/tmp/nb_sources.txt").write_text(txt, encoding="utf-8")
    print("SOURCE_PANEL_DUMPED /tmp/nb_sources.txt", len(txt), "chars")
finally:
    if ctx: ctx.close()
    if pw: pw.stop()
