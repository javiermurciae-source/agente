#!/usr/bin/env python3
"""Upload the staged transcripts into the Kontalid notebook via the
'Subir archivos' file-chooser."""
import os, sys, time, glob
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from patchright.sync_api import sync_playwright
from browser_utils import BrowserFactory, StealthUtils

import argparse
_ap = argparse.ArgumentParser()
_ap.add_argument("--src", default=os.path.expanduser("~/vault/kontalid_transcripciones/subir_notebook"))
_ap.add_argument("--pattern", default="*.txt")
_ap.add_argument("--notebook", default="https://notebook.google.com/notebook/ab32dffe-affa-4961-8c37-ee384ea290a5")
_args = _ap.parse_args()

NOTEBOOK = _args.notebook
SRC = os.path.expanduser(_args.src)

files = []
for _pat in [p.strip() for p in _args.pattern.split(",") if p.strip()]:
    files += glob.glob(os.path.join(SRC, _pat))
files = sorted(set(files))
print(f"Files to upload: {len(files)} from {SRC} ({_args.pattern})")

pw = ctx = None
try:
    pw = sync_playwright().start()
    ctx = BrowserFactory.launch_persistent_context(pw, headless=True)
    page = ctx.new_page()
    page.goto(NOTEBOOK, wait_until="domcontentloaded")
    page.wait_for_timeout(4000)

    def find_upload_btn():
        for b in page.query_selector_all("button"):
            if "subir archivos" in (b.inner_text() or "").lower():
                try:
                    if b.is_visible():
                        return b
                except Exception:
                    pass
        return None

    # Case A (empty notebook): 'Subir archivos' visible right away.
    # Case B (many sources loaded): reveal via Sources tab -> 'Agregar fuente'.
    btn = find_upload_btn()
    if not btn:
        try:
            page.click("text=Sources", timeout=6000)
            page.wait_for_timeout(1200)
        except Exception:
            pass
        try:
            af = page.wait_for_selector("button[aria-label='Agregar fuente']", state="visible", timeout=8000)
            af.click(force=True)
            page.wait_for_timeout(1200)
        except Exception as e:
            print("  (Agregar fuente:", str(e)[:50], ")")
        btn = find_upload_btn()
    if not btn:
        print("ERROR: no 'Subir archivos' button"); sys.exit(1)

    with page.expect_file_chooser(timeout=15000) as fc_info:
        btn.click(force=True)
    fc = fc_info.value
    print("File chooser opened; setting files...")
    fc.set_files(files)
    print("Files set. Waiting for processing...")

    # Wait for the upload dialog to close / sources to appear
    deadline = time.time() + 180
    while time.time() < deadline:
        page.wait_for_timeout(2000)
        # heuristic: dialog gone when 'Arrastra' overlay no longer visible
        still = page.query_selector("text=Arrastra y suelta")
        vis = False
        if still:
            try: vis = still.is_visible()
            except Exception: pass
        if not vis:
            print("  upload dialog closed (overlay gone)"); break

    page.wait_for_timeout(8000)  # extra settle for indexing
    # Count source chips in the sources panel
    chips = page.query_selector_all(".source-item, mat-list-item, [class*='source']")
    print(f"  source-ish elements found: {len(chips)}")
    print("UPLOAD_SCRIPT_DONE")
finally:
    if ctx: ctx.close()
    if pw: pw.stop()
