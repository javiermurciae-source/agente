#!/usr/bin/env python3
"""Stage the 41 transcripts with descriptive filenames for NotebookLM upload."""
import os, re, shutil

SRC = os.path.expanduser("~/vault/kontalid_transcripciones/por_video")
TSV = "/tmp/kontalid_videos.tsv"
DST = os.path.expanduser("~/vault/kontalid_transcripciones/subir_notebook")
os.makedirs(DST, exist_ok=True)

def sanitize(t, maxlen=60):
    t = re.sub(r"[^\w\sáéíóúñÁÉÍÓÚÑüÜ&.-]", "", t)
    t = re.sub(r"\s+", "_", t.strip())
    return t[:maxlen].strip("_")

rows = []
for ln in open(TSV, encoding="utf-8"):
    ln = ln.rstrip("\n")
    if not ln: continue
    line = ln.replace("\\t", "\t")
    title, _, url = line.partition("\t")
    vid = url.split("v=")[-1]
    rows.append((title, vid))

n = 0
manifest = []
for i, (title, vid) in enumerate(rows, 1):
    src = os.path.join(SRC, f"{vid}.txt")
    if not os.path.exists(src):
        print(f"MISSING {vid}"); continue
    fname = f"{i:02d}_{sanitize(title)}.txt"
    shutil.copy(src, os.path.join(DST, fname))
    n += 1
    manifest.append(fname)

print(f"Staged {n} files in {DST}")
for f in manifest[:5]:
    print("  e.g.", f)
